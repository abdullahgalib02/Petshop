package try1day1;
import java.io.*;
import java.util.Scanner;

public class Main {
    Scanner scanner= new Scanner(System.in);
    public static void main(String[] args) {
        
    }
    public void LoadData() throws FileNotFoundException {
        File file = new File("Admins.bin");
        try {
            FileInputStream input = new FileInputStream("Admins.bin");

        }catch (FileNotFoundException e){
            System.out.println(e.getMessage());
            
        }

    }
}


