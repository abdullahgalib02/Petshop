package try1day1;

public abstract class Pet {
    private String Name;

    private long PetID;
    private String Breed;
    private String HealthStatus=null;
    private boolean CanAdopt;
    public Pet(){
    }
    public Pet(String name, String breed) {
        this.Name = name;
        this.Breed = breed;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getBreed() {
        return Breed;
    }

    public void setBreed(String breed) {
        this.Breed = breed;
    }

    public String getHealthStatus() {
        return HealthStatus;
    }

    public void setHealthStatus(String healthStatus) {
        this.HealthStatus = healthStatus;
    }

    public void setCanAdopt(boolean canAdopt) {
        this.CanAdopt = canAdopt;
    }

}
