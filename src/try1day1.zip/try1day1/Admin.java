package try1day1;

public class Admin extends User{
    private long SecondaryPin;
    private String UserName;
    public Admin(){
        super();
    }
    public Admin(String name, String userName, String password, long secondaryPin){
        super(name, password);
        this.SecondaryPin= secondaryPin;
        this.UserName= userName;
    }

    public void setSecondaryPin(long secondaryPin) {
        SecondaryPin = secondaryPin;
    }

    public long getSecondaryPin() {
        return SecondaryPin;
    }

    @Override
    public String getPassword() {
        return super.getPassword();
    }


    public void setUserName(String userName) {
        UserName = userName;
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public void setPassword(String password) {
        super.setPassword(password);
    }

    @Override
    public String getUserName() {
        return UserName;
    }

    @Override
    public String getName() {
        return super.getName();
    }

}
