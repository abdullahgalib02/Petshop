package try1day1;

public class Cat extends Pet {
    String FurColor;

    public Cat() {
        super();
    }

    public Cat(String name, String breed, String furColor) {
        super(name, breed);
        this.FurColor = furColor;
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public void setBreed(String breed) {
        super.setBreed(breed);
    }

    @Override
    public String getBreed() {
        return super.getBreed();
    }

    @Override
    public void setHealthStatus(String healthStatus) {
        super.setHealthStatus(healthStatus);
    }

    @Override
    public String getHealthStatus() {
        return super.getHealthStatus();
    }

    public void setFurColor(String furColor) {
        this.FurColor = furColor;
    }

    public String getFurColor() {
        return FurColor;
    }

    @Override
    public void setCanAdopt(boolean canAdopt) {
        super.setCanAdopt(canAdopt);
    }
}
