package try1day1;

import java.util.ArrayList;

public class Customer extends User{
    private ArrayList<Pet> PetsAdopted= new ArrayList<>();
    private long CustomerID;
    String UserName;
    public Customer(){
        super();
    }
    public Customer(String name, String password, String userName, long customerID){
        super(name, password);
        this.UserName= userName;
        this.CustomerID= customerID;
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public String getName() {
        return super.getName();
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getUserName() {
        return UserName;
    }

    public void setCustomerID(long customerID) {
        CustomerID = customerID;
    }

    public long getCustomerID() {
        return CustomerID;
    }

    @Override
    public String getPassword() {
        return super.getPassword();
    }

    @Override
    public void setPassword(String password) {
        super.setPassword(password);
    }
}
